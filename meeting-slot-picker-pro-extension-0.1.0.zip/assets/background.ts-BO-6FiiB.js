chrome.runtime.onInstalled.addListener(e=>{e.reason==="install"&&console.log("[meeting-slot-picker] installed")});
