import{invoke as i}from"./core-DhEqZVGG.js";async function l(a,e){await i("plugin:clipboard-manager|write_text",{label:e==null?void 0:e.label,text:a})}export{l as writeText};
